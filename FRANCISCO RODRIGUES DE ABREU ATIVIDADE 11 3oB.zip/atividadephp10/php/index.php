<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($_POST['ano_nascimento']) ? 'Resultado' : 'Calculadora de Idade'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
       
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 500px;
        }

    
        .card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .card h1 {
            color: #333;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .card p {
            color: #666;
            margin-bottom: 20px;
        }

        
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 400;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }

        .form-group input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
            outline: none;
        }

      
        .btn {
            background: linear-gradient(to right, #667eea, #764ba2);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-block;
            text-decoration: none;
            margin-top: 10px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

       
        .result-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            text-align: left;
        }

        .result-box p {
            margin: 10px 0;
            color: #333;
            font-size: 18px;
        }

        .result-box span {
            font-weight: 600;
            color: #667eea;
        }

        .message {
            font-style: italic;
            color: #764ba2 !important;
            margin-top: 15px !important;
            font-weight: 500;
        }

        .error {
            color: #e74c3c !important;
            font-weight: 500;
        }

     
        @media (max-width: 600px) {
            .card {
                padding: 20px;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
   <H3> EXERCICIO 1 ATIVIDADE 11</H3>

<div class="container">
        <?php if (!isset($_POST['ano_nascimento'])): ?>
           
            <div class="card">
                <h1>Calculadora de Idade</h1>
                <p>Descubra quantos anos você terá em 2024</p>
                
                <form method="post">
                    <div class="form-group">
                        <label for="ano_nascimento">Ano de Nascimento:</label>
                        <input type="number" id="ano_nascimento" name="ano_nascimento" 
                               placeholder="Digite seu ano de nascimento" required>
                    </div>
                    
                    <button type="submit" class="btn">Calcular Idade</button>
                </form>
            </div>
        <?php else: ?>
          
            <div class="card result">
                <h1>Resultado do Cálculo</h1>
                
                <?php
                $ano_nascimento = intval($_POST['ano_nascimento']);
                $ano_atual = 2024;
                $idade = $ano_atual - $ano_nascimento;
                
                echo "<div class='result-box'>";
                echo "<p>Ano de Nascimento: <span>$ano_nascimento</span></p>";
                echo "<p>Idade em 2024: <span>$idade anos</span></p>";
                
            
                if ($idade < 0) {
                    echo "<p class='message'>Você ainda não nasceu!</p>";
                } elseif ($idade < 18) {
                    echo "<p class='message'>Você será menor de idade em 2024</p>";
                } elseif ($idade >= 100) {
                    echo "<p class='message'>Uau! Você é um centenário!</p>";
                } else {
                    echo "<p class='message'>Em 2024 você será adulto</p>";
                }
                
                echo "</div>";
                ?>
                
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn">Calcular Novamente</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>