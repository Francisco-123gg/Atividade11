<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($_POST['base']) ? 'Resultado' : 'Calculadora de Retângulo'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 500px;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .card h1 {
            color: #333;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .card p {
            color: #666;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 400;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }

        .form-group input:focus {
            border-color: #4facfe;
            box-shadow: 0 0 0 3px rgba(79, 172, 254, 0.2);
            outline: none;
        }

        .btn {
            background: linear-gradient(to right, #4facfe, #00f2fe);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-block;
            text-decoration: none;
            margin-top: 10px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .result-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            text-align: left;
        }

        .result-box p {
            margin: 10px 0;
            color: #333;
            font-size: 18px;
        }

        .result-box span {
            font-weight: 600;
            color: #4facfe;
        }

        .error {
            color: #e74c3c !important;
            font-weight: 500;
        }

        @media (max-width: 600px) {
            .card {
                padding: 20px;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<H3>EXERCICIO 2 ATIVIDADE 11</H3>
    <div class="container">
        <?php if (!isset($_POST['base']) || !isset($_POST['altura'])): ?>
            <div class="card">
                <h1>Calculadora de Retângulo</h1>
                <p>Informe as medidas para calcular área e perímetro</p>
                
                <form method="post">
                    <div class="form-group">
                        <label for="base">Base (cm):</label>
                        <input type="number" id="base" name="base" step="0.01" min="0.01"
                               placeholder="Digite a medida da base" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="altura">Altura (cm):</label>
                        <input type="number" id="altura" name="altura" step="0.01" min="0.01"
                               placeholder="Digite a medida da altura" required>
                    </div>
                    
                    <button type="submit" class="btn">Calcular</button>
                </form>
            </div>
        <?php else: ?>
            <div class="card result">
                <h1>Resultados do Retângulo</h1>
                
                <?php
                $base = floatval($_POST['base']);
                $altura = floatval($_POST['altura']);
                
                $area = $base * $altura;
                $perimetro = 2 * ($base + $altura);
                
                $base_formatada = number_format($base, 2, ',', '.');
                $altura_formatada = number_format($altura, 2, ',', '.');
                $area_formatada = number_format($area, 2, ',', '.');
                $perimetro_formatado = number_format($perimetro, 2, ',', '.');
                
                echo "<div class='result-box'>";
                echo "<p>Base: <span>{$base_formatada} cm</span></p>";
                echo "<p>Altura: <span>{$altura_formatada} cm</span></p>";
                echo "<p>Área: <span>{$area_formatada} cm²</span></p>";
                echo "<p>Perímetro: <span>{$perimetro_formatado} cm</span></p>";
                echo "</div>";
                ?>
                
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn">Novo Cálculo</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>