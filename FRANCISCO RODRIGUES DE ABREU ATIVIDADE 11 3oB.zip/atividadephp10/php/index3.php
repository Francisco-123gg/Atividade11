<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($_POST['peso']) ? 'Resultado IMC' : 'Calculadora de IMC'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #a1c4fd 0%, #c2e9fb 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 500px;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .card h1 {
            color: #333;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .card p {
            color: #666;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 400;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }

        .form-group input:focus {
            border-color: #a1c4fd;
            box-shadow: 0 0 0 3px rgba(161, 196, 253, 0.2);
            outline: none;
        }

        .btn {
            background: linear-gradient(to right, #a1c4fd, #c2e9fb);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-block;
            text-decoration: none;
            margin-top: 10px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .result-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            text-align: left;
        }

        .result-box p {
            margin: 10px 0;
            color: #333;
            font-size: 18px;
        }

        .result-box span {
            font-weight: 600;
            color: #a1c4fd;
        }

        .healthy {
            color: #2ecc71 !important;
            font-weight: 500;
            margin-top: 15px !important;
        }

        .overweight {
            color: #e74c3c !important;
            font-weight: 500;
            margin-top: 15px !important;
        }

        .error {
            color: #e74c3c !important;
            font-weight: 500;
        }

        @media (max-width: 600px) {
            .card {
                padding: 20px;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<H3>EXERCICIO 3 ATIVIDADE 11</H3>
    <div class="container">
        <?php if (!isset($_POST['peso']) || !isset($_POST['altura'])): ?>
            <div class="card">
                <h1>Calculadora de IMC</h1>
                <p>Informe seu peso e altura para calcular seu Índice de Massa Corporal</p>
                
                <form method="post">
                    <div class="form-group">
                        <label for="peso">Peso (kg):</label>
                        <input type="number" id="peso" name="peso" step="0.1" min="30" max="300"
                               placeholder="Digite seu peso em quilogramas" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="altura">Altura (m):</label>
                        <input type="number" id="altura" name="altura" step="0.01" min="1.20" max="2.50"
                               placeholder="Digite sua altura em metros" required>
                    </div>
                    
                    <button type="submit" class="btn">Calcular IMC</button>
                </form>
            </div>
        <?php else: ?>
            <div class="card result">
                <h1>Resultado do IMC</h1>
                
                <?php
                $peso = floatval($_POST['peso']);
                $altura = floatval($_POST['altura']);
                
                $imc = $peso / ($altura * $altura);
                $imc_formatado = number_format($imc, 2, ',', '.');
                
                echo "<div class='result-box'>";
                echo "<p>Peso: <span>{$peso} kg</span></p>";
                echo "<p>Altura: <span>{$altura} m</span></p>";
                echo "<p>Seu IMC: <span>{$imc_formatado}</span></p>";
                
              
                if ($imc > 25) {
                    echo "<p class='overweight'>Você está acima do peso!</p>";
                } else {
                    echo "<p class='healthy'>Você está saudável!</p>";
                }
                
                echo "</div>";
                ?>
                
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn">Novo Cálculo</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>