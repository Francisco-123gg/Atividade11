<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($_POST['username']) ? 'Resultado' : 'Login'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 400px;
        }

        .card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .card h1 {
            color: #333;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 400;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: all 0.3s;
        }

        .form-group input:focus {
            border-color: #4e73df;
            box-shadow: 0 0 0 3px rgba(78, 115, 223, 0.1);
            outline: none;
        }

        .btn {
            background: #4e73df;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            margin-top: 10px;
        }

        .btn:hover {
            background: #3a56c4;
        }

        .message {
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
            font-weight: 500;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            color: #4e73df;
            text-decoration: none;
            font-weight: 500;
        }

        .back-btn:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<H3>EXERCICIO 4 ATIVIDADE 11</H3>
    <div class="container">
        <?php
        $valid_username = "maria";
        $valid_password = "12345";
        
        if (!isset($_POST['username'])): ?>
            <div class="card">
                <h1>Acesso Restrito</h1>
                <form method="post">
                    <div class="form-group">
                        <label for="username">Usuário:</label>
                        <input type="text" id="username" name="username" 
                               placeholder="Digite seu nome de usuário" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Senha:</label>
                        <input type="password" id="password" name="password" 
                               placeholder="Digite sua senha" required>
                    </div>
                    
                    <button type="submit" class="btn">Entrar</button>
                </form>
            </div>
        <?php else: 
            $username = trim($_POST['username']);
            $password = trim($_POST['password']);
            
            if ($username === $valid_username && $password === $valid_password) {
                $message = "Autenticação realizada com sucesso";
                $class = "success";
            } else {
                $message = "Você não tem permissão de visualizar essa página";
                $class = "error";
            }
            ?>
            
            <div class="card">
                <h1>Resultado</h1>
                <div class="message <?php echo $class; ?>">
                    <?php echo $message; ?>
                </div>
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="back-btn">← Voltar ao login</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>