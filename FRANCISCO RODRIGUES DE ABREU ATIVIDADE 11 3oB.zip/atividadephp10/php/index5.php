<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($_POST['numero']) ? 'Tabuada' : 'Selecione um Número'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 500px;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .card h1 {
            color: #333;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 400;
        }

        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            background-color: white;
            transition: all 0.3s;
        }

        .form-group select:focus {
            border-color: #f5576c;
            box-shadow: 0 0 0 3px rgba(245, 87, 108, 0.2);
            outline: none;
        }

        .btn {
            background: linear-gradient(to right, #f5576c, #f093fb);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            margin-top: 10px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .tabuada {
            margin: 25px 0;
            width: 100%;
            border-collapse: collapse;
        }

        .tabuada th {
            background-color: #f5576c;
            color: white;
            padding: 10px;
        }

        .tabuada td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        .tabuada tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            color: #f5576c;
            text-decoration: none;
            font-weight: 500;
        }

        .back-btn:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<H3>EXERCICIO 5 ATIVIDADE 11</H3>
    <div class="container">
        <?php if (!isset($_POST['numero'])): ?>
            <div class="card">
                <h1>Tabuada de Multiplicação</h1>
                <p>Selecione um número de 1 a 9 para ver sua tabuada</p>
                
                <form method="post">
                    <div class="form-group">
                        <label for="numero">Número:</label>
                        <select id="numero" name="numero" required>
                            <option value="" disabled selected>Selecione um número</option>
                            <?php for ($i = 1; $i <= 9; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn">Mostrar Tabuada</button>
                </form>
            </div>
        <?php else: 
            $numero = intval($_POST['numero']);
            ?>
            
            <div class="card">
                <h1>Tabuada do <?php echo $numero; ?></h1>
                
                <table class="tabuada">
                    <thead>
                        <tr>
                            <th>Multiplicação</th>
                            <th>Resultado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 1; $i <= 10; $i++): ?>
                            <tr>
                                <td><?php echo "$numero × $i"; ?></td>
                                <td><?php echo $numero * $i; ?></td>
                            </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
                
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="back-btn">← Voltar</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>