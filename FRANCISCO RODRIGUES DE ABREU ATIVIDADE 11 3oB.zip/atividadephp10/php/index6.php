<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($_POST['nome1']) ? 'Nomes Ordenados' : 'Cadastro de Nomes'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 600px;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }

        .form-group input:focus {
            border-color: #84fab0;
            outline: none;
            box-shadow: 0 0 0 3px rgba(132, 250, 176, 0.2);
        }

        .btn {
            background: linear-gradient(to right, #84fab0, #8fd3f4);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            transition: all 0.3s;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .resultado {
            margin-top: 30px;
        }

        .resultado h2 {
            color: #333;
            margin-bottom: 15px;
            text-align: center;
        }

        .lista-nomes {
            list-style-type: none;
        }

        .lista-nomes li {
            background: #f8f9fa;
            margin-bottom: 8px;
            padding: 12px 15px;
            border-radius: 8px;
            border-left: 4px solid #84fab0;
        }

        .back-btn {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #84fab0;
            text-decoration: none;
            font-weight: 500;
        }

        .back-btn:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<H3>EXERCICIO 6 ATIVIDADE 11</H3>
    <div class="container">
        <?php if (!isset($_POST['nome1'])): ?>
            <div class="card">
                <h1>Cadastre 5 Nomes</h1>
                <form method="post">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <div class="form-group">
                            <label for="nome<?php echo $i; ?>">Nome <?php echo $i; ?>:</label>
                            <input type="text" id="nome<?php echo $i; ?>" name="nome<?php echo $i; ?>" required>
                        </div>
                    <?php endfor; ?>
                    
                    <button type="submit" class="btn">Ordenar Nomes</button>
                </form>
            </div>
        <?php else: 
            $nomes = array();
            for ($i = 1; $i <= 5; $i++) {
                $nome = trim($_POST["nome$i"]);
                if (!empty($nome)) {
                    $nomes[] = ucwords(strtolower($nome));
                }
            }
            
            sort($nomes);
            ?>
            
            <div class="card">
                <h1>Nomes Ordenados Alfabeticamente</h1>
                
                <div class="resultado">
                    <h2>Lista de Nomes</h2>
                    <ul class="lista-nomes">
                        <?php foreach ($nomes as $nome): ?>
                            <li><?php echo htmlspecialchars($nome); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="back-btn">← Voltar</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>