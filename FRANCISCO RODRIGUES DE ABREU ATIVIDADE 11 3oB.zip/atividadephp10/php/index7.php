<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($_POST['nome']) ? 'Resultado' : 'Formulário de Perfil Político'; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .form-container, .result-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .radio-group, .checkbox-group {
            margin-top: 5px;
        }
        .radio-group label, .checkbox-group label {
            font-weight: normal;
            display: inline-block;
            margin-right: 15px;
        }
        textarea {
            height: 100px;
            resize: vertical;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        button:hover {
            background-color: #45a049;
        }
        .result-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .result-item strong {
            display: inline-block;
            width: 200px;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 30px;
            color: #4CAF50;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<H3>EXERCICIO 7 ATIVIDADE 11</H3>
    <?php
    function clean_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome = clean_input($_POST["nome"]);
        $idade = clean_input($_POST["idade"]);
        $naturalidade = clean_input($_POST["naturalidade"]);
        $nacionalidade = clean_input($_POST["nacionalidade"]);
        $votou = isset($_POST["votou"]) ? clean_input($_POST["votou"]) : '';
        $partido = clean_input($_POST["partido"]);
        $avaliacao = clean_input($_POST["avaliacao"]);
        $problemas = clean_input($_POST["problemas"]);
        
        $avaliacao_display = [
            'otima' => 'Ótima',
            'bom' => 'Boa',
            'regular' => 'Regular',
            'pessimo' => 'Péssima'
        ];
        ?>
        
        <div class="result-container">
            <h1>Dados Recebidos</h1>
            
            <div class="result-item"><strong>Nome:</strong> <?php echo $nome; ?></div>
            <div class="result-item"><strong>Idade:</strong> <?php echo $idade; ?> anos</div>
            <div class="result-item"><strong>Naturalidade:</strong> <?php echo $naturalidade; ?></div>
            <div class="result-item"><strong>Nacionalidade:</strong> <?php echo $nacionalidade; ?></div>
            <div class="result-item"><strong>Votou na última eleição:</strong> <?php echo ucfirst($votou); ?></div>
            <div class="result-item"><strong>Partido que se identifica:</strong> <?php echo $partido; ?></div>
            <div class="result-item"><strong>Avaliação da administração:</strong> <?php echo $avaliacao_display[$avaliacao]; ?></div>
            <div class="result-item"><strong>Principais problemas da cidade:</strong><br><?php echo nl2br($problemas); ?></div>
            
            <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="back-link">← Voltar ao formulário</a>
        </div>
    <?php } else { ?>
        <div class="form-container">
            <h1>Formulário de Perfil Político</h1>
            
            <form method="post">
                <div class="form-group">
                    <label for="nome">Nome Completo:</label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                
                <div class="form-group">
                    <label for="idade">Idade:</label>
                    <input type="number" id="idade" name="idade" min="16" required>
                </div>
                
                <div class="form-group">
                    <label for="naturalidade">Naturalidade:</label>
                    <input type="text" id="naturalidade" name="naturalidade" required>
                </div>
                
                <div class="form-group">
                    <label for="nacionalidade">Nacionalidade:</label>
                    <input type="text" id="nacionalidade" name="nacionalidade" required>
                </div>
                
                <div class="form-group">
                    <label>Você votou na eleição anterior para prefeito?</label>
                    <div class="radio-group">
                        <label><input type="radio" name="votou" value="sim" required> Sim</label>
                        <label><input type="radio" name="votou" value="nao"> Não</label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="partido">Com qual partido você mais se identifica?</label>
                    <select id="partido" name="partido" required>
                        <option value="">Selecione...</option>
                        <option value="PT">PT</option>
                        <option value="PSDD">PSDD</option>
                        <option value="Democratas">Democratas</option>
                        <option value="PSTU">PSTU</option>
                        <option value="Outro">Outro</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="avaliacao">Como você classifica a administração atual?</label>
                    <select id="avaliacao" name="avaliacao" required>
                        <option value="">Selecione...</option>
                        <option value="otima">Ótima</option>
                        <option value="bom">Boa</option>
                        <option value="regular">Regular</option>
                        <option value="pessimo">Péssima</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="problemas">Quais são os principais problemas da cidade atualmente?</label>
                    <textarea id="problemas" name="problemas" required></textarea>
                </div>
                
                <button type="submit">Enviar Formulário</button>
            </form>
        </div>
    <?php } ?>
</body>
</html>