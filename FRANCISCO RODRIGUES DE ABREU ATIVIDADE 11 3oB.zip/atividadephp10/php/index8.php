<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($_POST['num1']) ? 'Resultado' : 'Calculadora'; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 30px;
            width: 100%;
            max-width: 500px;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #4e73df;
            box-shadow: 0 0 0 2px rgba(78, 115, 223, 0.25);
        }
        button {
            background: #4e73df;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            transition: background 0.3s;
        }
        button:hover {
            background: #3a56c4;
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
            border-left: 4px solid #4e73df;
        }
        .result p {
            margin: 5px 0;
            font-size: 18px;
        }
        .result span {
            font-weight: bold;
            color: #4e73df;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #4e73df;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <H3>EXERCICIO 8 ATIVIDADE 11</H3>
    <div class="container">
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['num1'], $_POST['num2'], $_POST['operacao'])) {
            $num1 = (float)$_POST['num1'];
            $num2 = (float)$_POST['num2'];
            $operacao = $_POST['operacao'];
            $resultado = 0;
            $simbolo = '';
            $erro = '';
            
            switch ($operacao) {
                case 'soma':
                    $resultado = $num1 + $num2;
                    $simbolo = '+';
                    break;
                case 'subtracao':
                    $resultado = $num1 - $num2;
                    $simbolo = '-';
                    break;
                case 'multiplicacao':
                    $resultado = $num1 * $num2;
                    $simbolo = '×';
                    break;
                case 'divisao':
                    if ($num2 != 0) {
                        $resultado = $num1 / $num2;
                        $simbolo = '÷';
                    } else {
                        $erro = 'Erro: Divisão por zero!';
                    }
                    break;
                default:
                    $erro = 'Operação inválida!';
            }
            ?>
            
            <h1>Resultado</h1>
            <div class="result">
                <?php if ($erro): ?>
                    <p style="color: #e74c3c;"><?php echo $erro; ?></p>
                <?php else: ?>
                    <p><?php echo "$num1 $simbolo $num2 = <span>$resultado</span>"; ?></p>
                <?php endif; ?>
            </div>
            <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="back-link">← Nova operação</a>
            
        <?php } else { ?>
            <h1>Calculadora</h1>
            <form method="post">
                <div class="form-group">
                    <label for="num1">Primeiro número:</label>
                    <input type="number" id="num1" name="num1" step="any" required>
                </div>
                
                <div class="form-group">
                    <label for="operacao">Operação:</label>
                    <select id="operacao" name="operacao" required>
                        <option value="">Selecione...</option>
                        <option value="soma">Soma (+)</option>
                        <option value="subtracao">Subtração (-)</option>
                        <option value="multiplicacao">Multiplicação (×)</option>
                        <option value="divisao">Divisão (÷)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="num2">Segundo número:</label>
                    <input type="number" id="num2" name="num2" step="any" required>
                </div>
                
                <button type="submit">Calcular</button>
            </form>
        <?php } ?>
    </div>
</body>
</html>